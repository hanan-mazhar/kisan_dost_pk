import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../../providers/auth_provider.dart';
import '../../services/product_service.dart';
import '../../models/product_model.dart';
import '../../theme/app_theme.dart';
import '../../utils/constants.dart';
import '../../widgets/custom_text_field.dart';

class AddProductScreen extends StatefulWidget {
  final ProductModel? editProduct;
  const AddProductScreen({super.key, this.editProduct});
  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _quantityCtrl = TextEditingController();
  final _descCtrl = TextEditingController();

  String _selectedCategory = 'Wheat';
  String _selectedUnit = 'kg';
  String _selectedLocation = '';
  List<File> _pickedImages = [];
  List<String> _existingImagePaths = [];
  bool _isLoading = false;
  final _productService = ProductService();

  bool get _isEditing => widget.editProduct != null;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      final p = widget.editProduct!;
      _nameCtrl.text = p.name;
      _priceCtrl.text = p.pricePerUnit.toStringAsFixed(0);
      _quantityCtrl.text = p.quantityAvailable.toString();
      _descCtrl.text = p.description;
      _selectedLocation = p.location;
      _selectedCategory = p.category;
      _selectedUnit = p.unit;
      _existingImagePaths = List.from(p.imagePaths);
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _priceCtrl.dispose();
    _quantityCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
    final picker = ImagePicker();
    final images = await picker.pickMultiImage(imageQuality: 75);
    if (images.isNotEmpty) {
      setState(() => _pickedImages = images.map((x) => File(x.path)).toList());
    }
  }

  Future<void> _pickFromCamera() async {
    final picker = ImagePicker();
    final img = await picker.pickImage(source: ImageSource.camera, imageQuality: 75);
    if (img != null) setState(() => _pickedImages.add(File(img.path)));
  }

  Future<void> _pickLocation() async {
    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _CityPickerSheet(),
    );
    if (result != null) setState(() => _selectedLocation = result);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final user = context.read<AuthProvider>().currentUser!;
    final location = _selectedLocation.isNotEmpty ? _selectedLocation : user.city;
    setState(() => _isLoading = true);
    try {
      if (_isEditing) {
        final updated = widget.editProduct!.copyWith(
          name: _nameCtrl.text.trim(),
          category: _selectedCategory,
          pricePerUnit: double.parse(_priceCtrl.text),
          unit: _selectedUnit,
          quantityAvailable: int.parse(_quantityCtrl.text),
          description: _descCtrl.text.trim(),
          location: location,
        );
        await _productService.updateProduct(updated,
            newImages: _pickedImages.isNotEmpty ? _pickedImages : null);
      } else {
        final product = ProductModel(
          id: '',
          farmerId: user.id,
          farmerName: user.fullName,
          farmerPhone: user.phoneNumber,
          farmerCity: user.city,
          farmerRating: user.rating,
          name: _nameCtrl.text.trim(),
          category: _selectedCategory,
          pricePerUnit: double.parse(_priceCtrl.text),
          unit: _selectedUnit,
          quantityAvailable: int.parse(_quantityCtrl.text),
          location: location,
          imagePaths: [],
          description: _descCtrl.text.trim(),
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );
        await _productService.addProduct(product,
            localImages: _pickedImages.isNotEmpty ? _pickedImages : null);
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(_isEditing ? '✅ Product updated!' : '✅ Product added!'),
        backgroundColor: AppTheme.successGreen,
        behavior: SnackBarBehavior.floating,
      ));
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error: ${e.toString()}'),
        backgroundColor: AppTheme.errorRed,
      ));
    }
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser;
    // Auto-fill location from profile on first open
    if (_selectedLocation.isEmpty && user != null && user.city.isNotEmpty) {
      _selectedLocation = user.city;
    }

    return Scaffold(
      appBar: AppBar(title: Text(_isEditing ? 'Edit Product' : 'Add New Product')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Images ───────────────────────────────────────────────────
              Text('Product Images', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text('Add photos to attract more buyers', style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 10),
              SizedBox(
                height: 110,
                child: Row(children: [
                  Column(children: [
                    _ImageAddBtn(icon: Icons.photo_library_outlined, label: 'Gallery', onTap: _pickImages),
                    const SizedBox(height: 8),
                    _ImageAddBtn(icon: Icons.camera_alt_outlined, label: 'Camera', onTap: _pickFromCamera),
                  ]),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        ..._existingImagePaths.map((path) {
                          final f = File(path);
                          return _ImageThumb(
                            child: f.existsSync()
                                ? Image.file(f, fit: BoxFit.cover, width: 90, height: 90)
                                : _cropPlaceholder(_selectedCategory),
                            onRemove: () => setState(() => _existingImagePaths.remove(path)),
                          );
                        }),
                        ..._pickedImages.map((f) => _ImageThumb(
                              child: Image.file(f, fit: BoxFit.cover, width: 90, height: 90),
                              onRemove: () => setState(() => _pickedImages.remove(f)),
                            )),
                        if (_existingImagePaths.isEmpty && _pickedImages.isEmpty)
                          _cropPlaceholder(_selectedCategory),
                      ],
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 20),

              // ── Category ─────────────────────────────────────────────────
              Text('Crop Category', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              SizedBox(
                height: 82,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: AppConstants.cropCategories.length - 1,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) {
                    final cat = AppConstants.cropCategories.where((c) => c != 'All').toList()[i];
                    final isSelected = cat == _selectedCategory;
                    return GestureDetector(
                      onTap: () => setState(() {
                        _selectedCategory = cat;
                        if (_nameCtrl.text.isEmpty) _nameCtrl.text = cat;
                      }),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        width: 68,
                        decoration: BoxDecoration(
                          color: isSelected
                              ? Color(AppConstants.getCropColor(cat)).withOpacity(0.15)
                              : AppTheme.cardWhite,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: isSelected ? Color(AppConstants.getCropColor(cat)) : AppTheme.divider,
                            width: isSelected ? 2 : 1,
                          ),
                        ),
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text(AppConstants.getCropEmoji(cat), style: const TextStyle(fontSize: 26)),
                          const SizedBox(height: 4),
                          Text(
                            cat,
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                              color: isSelected ? Color(AppConstants.getCropColor(cat)) : AppTheme.textMedium,
                            ),
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ]),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),

              // ── Name ─────────────────────────────────────────────────────
              CustomTextField(
                controller: _nameCtrl,
                label: 'Product Name',
                hint: 'e.g., Premium Wheat, Basmati Rice',
                prefixIcon: Icons.grass_outlined,
                validator: (v) => v == null || v.trim().isEmpty ? 'Name is required' : null,
              ),
              const SizedBox(height: 14),

              // ── Price & Unit ──────────────────────────────────────────────
              Row(children: [
                Expanded(
                  flex: 2,
                  child: CustomTextField(
                    controller: _priceCtrl,
                    label: 'Price (PKR)',
                    hint: '2600',
                    prefixIcon: Icons.payments_outlined,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    validator: (v) {
                      if (v == null || v.trim().isEmpty) return 'Required';
                      if (double.tryParse(v) == null) return 'Invalid number';
                      if (double.parse(v) <= 0) return 'Must be > 0';
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    initialValue: _selectedUnit,
                    decoration: InputDecoration(
                      labelText: 'Unit',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                    ),
                    items: ['kg', '40kg', 'quintal', 'maund', 'ton', 'piece']
                        .map((u) => DropdownMenuItem(value: u, child: Text(u)))
                        .toList(),
                    onChanged: (v) => setState(() => _selectedUnit = v!),
                  ),
                ),
              ]),
              const SizedBox(height: 14),

              // ── Quantity ──────────────────────────────────────────────────
              CustomTextField(
                controller: _quantityCtrl,
                label: 'Quantity Available',
                hint: '80',
                prefixIcon: Icons.inventory_2_outlined,
                keyboardType: TextInputType.number,
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return 'Required';
                  if (int.tryParse(v) == null) return 'Must be whole number';
                  if (int.parse(v) <= 0) return 'Must be > 0';
                  return null;
                },
              ),
              const SizedBox(height: 14),

              // ── Location Picker ───────────────────────────────────────────
              Text('Location', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              GestureDetector(
                onTap: _pickLocation,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
                  decoration: BoxDecoration(
                    color: AppTheme.cardWhite,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppTheme.divider),
                  ),
                  child: Row(children: [
                    const Icon(Icons.location_on_outlined, color: AppTheme.primaryGreen, size: 20),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _selectedLocation.isEmpty ? 'Select city / district' : _selectedLocation,
                        style: TextStyle(
                          fontSize: 15,
                          color: _selectedLocation.isEmpty ? AppTheme.textMedium : AppTheme.textDark,
                        ),
                      ),
                    ),
                    const Icon(Icons.arrow_drop_down, color: AppTheme.textMedium),
                  ]),
                ),
              ),
              const SizedBox(height: 14),

              // ── Description ───────────────────────────────────────────────
              CustomTextField(
                controller: _descCtrl,
                label: 'Product Description',
                hint: 'Quality details, harvest date, storage info...',
                prefixIcon: Icons.description_outlined,
                maxLines: 3,
              ),
              const SizedBox(height: 28),

              // ── Submit ────────────────────────────────────────────────────
              LoadingButton(
                label: _isEditing ? 'Update Product' : 'Submit Product',
                isLoading: _isLoading,
                onPressed: _submit,
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _cropPlaceholder(String category) {
    return Container(
      width: 90,
      height: 90,
      decoration: BoxDecoration(
        color: Color(AppConstants.getCropColor(category)).withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.divider),
      ),
      child: Center(child: Text(AppConstants.getCropEmoji(category), style: const TextStyle(fontSize: 36))),
    );
  }
}

// ── Searchable City Picker ────────────────────────────────────────────────────

class _CityPickerSheet extends StatefulWidget {
  const _CityPickerSheet();
  @override
  State<_CityPickerSheet> createState() => _CityPickerSheetState();
}

class _CityPickerSheetState extends State<_CityPickerSheet> {
  final _searchCtrl = TextEditingController();
  List<String> _filtered = AppConstants.allPakistanCities;

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  void _filter(String q) {
    setState(() {
      _filtered = q.isEmpty
          ? AppConstants.allPakistanCities
          : AppConstants.allPakistanCities
              .where((c) => c.toLowerCase().contains(q.toLowerCase()))
              .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      maxChildSize: 0.95,
      minChildSize: 0.5,
      expand: false,
      builder: (_, scrollController) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(children: [
          const SizedBox(height: 8),
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Select Location', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 10),
              TextField(
                controller: _searchCtrl,
                autofocus: true,
                onChanged: _filter,
                decoration: InputDecoration(
                  hintText: 'Search city or district...',
                  prefixIcon: const Icon(Icons.search, color: AppTheme.primaryGreen),
                  suffixIcon: _searchCtrl.text.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear, size: 18),
                          onPressed: () { _searchCtrl.clear(); _filter(''); },
                        )
                      : null,
                  filled: true,
                  fillColor: AppTheme.background,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '${_filtered.length} locations available',
                style: const TextStyle(fontSize: 12, color: AppTheme.textMedium),
              ),
            ]),
          ),
          const Divider(height: 1),
          Expanded(
            child: _filtered.isEmpty
                ? const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('🔍', style: TextStyle(fontSize: 36)),
                    SizedBox(height: 8),
                    Text('No results found', style: TextStyle(color: AppTheme.textMedium)),
                  ]))
                : ListView.separated(
                    controller: scrollController,
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                    itemCount: _filtered.length,
                    separatorBuilder: (_, __) => const Divider(height: 1, color: AppTheme.divider),
                    itemBuilder: (_, i) {
                      final city = _filtered[i];
                      return ListTile(
                        dense: true,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 4),
                        leading: const Icon(Icons.location_on_outlined, color: AppTheme.primaryGreen, size: 20),
                        title: Text(city, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                        onTap: () => Navigator.pop(context, city),
                      );
                    },
                  ),
          ),
        ]),
      ),
    );
  }
}

// ── Reusable widgets ──────────────────────────────────────────────────────────

class _ImageAddBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _ImageAddBtn({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 68, height: 48,
        decoration: BoxDecoration(
          color: AppTheme.primaryGreen.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.primaryGreen.withOpacity(0.4)),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: AppTheme.primaryGreen, size: 18),
          Text(label, style: const TextStyle(fontSize: 9, color: AppTheme.primaryGreen, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

class _ImageThumb extends StatelessWidget {
  final Widget child;
  final VoidCallback onRemove;
  const _ImageThumb({required this.child, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Container(
        width: 90, height: 90,
        margin: const EdgeInsets.only(right: 8, top: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.divider),
        ),
        clipBehavior: Clip.antiAlias,
        child: child,
      ),
      Positioned(
        top: 0, right: 4,
        child: GestureDetector(
          onTap: onRemove,
          child: Container(
            width: 20, height: 20,
            decoration: const BoxDecoration(color: AppTheme.errorRed, shape: BoxShape.circle),
            child: const Icon(Icons.close, color: Colors.white, size: 12),
          ),
        ),
      ),
    ]);
  }
}
